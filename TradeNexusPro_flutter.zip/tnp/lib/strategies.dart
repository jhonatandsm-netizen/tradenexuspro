import 'dart:math';

class Candle {
  final int t; final double o, h, l, c;
  Candle(this.t, this.o, this.h, this.l, this.c);
}

class Vote { int buys = 0, sells = 0; double atr = 0; }

List<double> _ema(List<double> v, int n) {
  final k = 2 / (n + 1), r = <double>[v[0]];
  for (var i = 1; i < v.length; i++) r.add(v[i] * k + r[i - 1] * (1 - k));
  return r;
}

double _sma(List<double> v, int n) => v.sublist(v.length - n).reduce((a, b) => a + b) / n;

double _rsi(List<double> c, int n) {
  var g = 0.0, l = 0.0;
  for (var i = 1; i <= n; i++) { final d = c[i] - c[i - 1]; d > 0 ? g += d : l -= d; }
  g /= n; l /= n;
  for (var i = n + 1; i < c.length; i++) {
    final d = c[i] - c[i - 1];
    g = (g * (n - 1) + max(d, 0)) / n; l = (l * (n - 1) + max(-d, 0)) / n;
  }
  return l == 0 ? 100 : 100 - 100 / (1 + g / l);
}

double _atr(List<Candle> k, int n) {
  var s = 0.0;
  for (var i = k.length - n; i < k.length; i++) {
    s += [k[i].h - k[i].l, (k[i].h - k[i - 1].c).abs(), (k[i].l - k[i - 1].c).abs()].reduce(max);
  }
  return s / n;
}

/// [k] = velas FECHADAS (>= 210). Retorna votos das 7 estrategias.
Vote vote(List<Candle> k) {
  final c = k.map((x) => x.c).toList(), last = c.last, n = k.length;
  final s20 = _sma(c, 20), s50 = _sma(c, 50), e200 = _ema(c, 200).last, atr = _atr(k, 14);
  final e12 = _ema(c, 12), e26 = _ema(c, 26);
  final macd = [for (var i = 0; i < n; i++) e12[i] - e26[i]], sig = _ema(macd, 9);
  final m = macd.last, sg = sig.last;
  final sd = sqrt(c.sublist(n - 20).map((x) => pow(x - s20, 2)).reduce((a, b) => a + b) / 20);
  final v = List<int>.filled(7, 0);

  v[0] = s20 > s50 ? 1 : -1;                                   // Trend Following
  final prev = k.sublist(n - 21, n - 1);                       // Breakout EMA200
  if (last > e200 && last > prev.map((x) => x.h).reduce(max)) v[1] = 1;
  if (last < e200 && last < prev.map((x) => x.l).reduce(min)) v[1] = -1;
  final r = _rsi(c, 14);                                       // RSI Reversal
  if (r < 30) v[2] = 1; else if (r > 70) v[2] = -1;
  if (m > sg && m > 0) v[3] = 1; else if (m < sg && m < 0) v[3] = -1; // MACD
  if (last < s20 - 2 * sd) v[4] = 1; else if (last > s20 + 2 * sd) v[4] = -1; // Bollinger
  if (last < s50 - atr) v[5] = 1; else if (last > s50 + atr) v[5] = -1;       // Grid
  final w = k.sublist(n - 50);                                 // Fibonacci
  var hi = 0, lo = 0;
  for (var i = 0; i < w.length; i++) {
    if (w[i].h > w[hi].h) hi = i;
    if (w[i].l < w[lo].l) lo = i;
  }
  final hH = w[hi].h, lL = w[lo].l, rg = hH - lL;
  if (rg > 0) {
    if (lo < hi && last <= hH - .382 * rg && last >= hH - .618 * rg) v[6] = 1;
    if (hi < lo && last >= lL + .382 * rg && last <= lL + .618 * rg) v[6] = -1;
  }
  final o = Vote()..atr = atr;
  for (final x in v) { if (x > 0) o.buys++; if (x < 0) o.sells++; }
  return o;
}
