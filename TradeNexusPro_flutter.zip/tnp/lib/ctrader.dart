import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'strategies.dart';

/// Cliente cTrader Open API (JSON sobre WebSocket).
class CT {
  final bool live;
  CT(this.live);
  WebSocket? _ws; Timer? _hb; int? acct; int _n = 0;
  final _p = <String, Completer<Map>>{};

  Future<void> connect() async {
    _ws = await WebSocket.connect('wss://${live ? 'live' : 'demo'}.ctraderapi.com:5036');
    _ws!.listen((m) {
      final j = jsonDecode(m as String) as Map, id = j['clientMsgId'];
      if (id != null && _p.containsKey(id)) _p.remove(id)!.complete(j);
    }, onDone: () { for (final c in _p.values) { c.completeError('desconectado'); } _p.clear(); });
    _hb = Timer.periodic(const Duration(seconds: 20),
        (_) => _ws?.add(jsonEncode({'payloadType': 51, 'payload': {}})));
  }

  Future<Map> req(int t, Map p) async {
    final id = 'm${_n++}', c = Completer<Map>();
    _p[id] = c;
    _ws!.add(jsonEncode({'clientMsgId': id, 'payloadType': t, 'payload': p}));
    final r = await c.future.timeout(const Duration(seconds: 20));
    final pt = r['payloadType'];
    final pl = (r['payload'] as Map?) ?? {};
    if (pt == 2142 || pt == 50 || pt == 2132) throw '${pl['description'] ?? pl['errorCode'] ?? pl}';
    return pl;
  }

  Future<void> login(String id, String secret, String token) async {
    await req(2100, {'clientId': id, 'clientSecret': secret});
    final l = await req(2149, {'accessToken': token});
    final list = (l['ctidTraderAccount'] as List).cast<Map>().where((a) => (a['isLive'] == true) == live).toList();
    if (list.isEmpty) throw 'Nenhuma conta ${live ? 'real' : 'demo'} neste token';
    acct = (list.first['ctidTraderAccountId'] as num).toInt();
    await req(2102, {'ctidTraderAccountId': acct, 'accessToken': token});
  }

  Future<Map<String, int>> symbolIds() async {
    final r = await req(2114, {'ctidTraderAccountId': acct});
    return {for (final s in (r['symbol'] as List).cast<Map>()) s['symbolName'] as String: (s['symbolId'] as num).toInt()};
  }

  Future<Map> detail(int id) async {
    final r = await req(2116, {'ctidTraderAccountId': acct, 'symbolId': [id]});
    return (r['symbol'] as List).first as Map;
  }

  Future<List<Candle>> bars(int id) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final r = await req(2137, {
      'ctidTraderAccountId': acct, 'symbolId': id, 'period': 9, // H1
      'fromTimestamp': now - 25 * 86400000, 'toTimestamp': now,
    });
    return (r['trendbar'] as List).cast<Map>().map((b) {
      final lo = (b['low'] as num).toDouble();
      double p(String k) => (lo + ((b[k] as num?) ?? 0)) / 100000;
      return Candle((b['utcTimestampInMinutes'] as num).toInt(), p('deltaOpen'), p('deltaHigh'), lo / 100000, p('deltaClose'));
    }).toList();
  }

  Future<List<Map>> positions() async =>
      ((await req(2124, {'ctidTraderAccountId': acct}))['position'] as List? ?? []).cast<Map>();

  Future<void> market(int sid, bool buy, int vol, double slDist, double tpDist) => req(2106, {
        'ctidTraderAccountId': acct, 'symbolId': sid, 'orderType': 1, 'tradeSide': buy ? 1 : 2,
        'volume': vol, 'relativeStopLoss': (slDist * 100000).round(), 'relativeTakeProfit': (tpDist * 100000).round(),
      });

  void close() { _hb?.cancel(); _ws?.close(); }
}
