import 'dart:async';
import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'ctrader.dart';
import 'strategies.dart';

void main() => runApp(MaterialApp(
    theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true), home: const Home()));

class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState() => _S(); }

class _S extends State<Home> {
  final cid = TextEditingController(), sec = TextEditingController(), tok = TextEditingController();
  final lots = TextEditingController(text: '0.01'), votes = TextEditingController(text: '3');
  final syms = TextEditingController(text: 'EURUSD,GBPUSD,XAUUSD,BTCUSD,ETHUSD');
  bool live = false, running = false, busy = false;
  CT? ct; Timer? tm;
  final logs = <String>[], seen = <String, int>{}, ids = <String, int>{}, det = <int, Map>{};

  void log(String s) { if (mounted) setState(() => logs.insert(0, '${TimeOfDay.now().format(context)}  $s')); }

  Future<void> start() async {
    if (live) {
      final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
        title: const Text('Conta REAL'),
        content: const Text('O app vai operar com dinheiro real. Confirmar?'),
        actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Confirmar'))]));
      if (ok != true) return;
    }
    setState(() => running = true);
    try {
      ct = CT(live);
      await ct!.connect();
      await ct!.login(cid.text.trim(), sec.text.trim(), tok.text.trim());
      log('Conectado (${live ? 'REAL' : 'DEMO'}) conta ${ct!.acct}');
      final all = await ct!.symbolIds();
      ids.clear(); seen.clear();
      for (final s in syms.text.split(',').map((e) => e.trim())) {
        all.containsKey(s) ? ids[s] = all[s]! : log('Simbolo nao existe: $s');
      }
      WakelockPlus.enable();
      tm = Timer.periodic(const Duration(seconds: 60), (_) => scan());
      scan();
    } catch (e) { log('Erro: $e'); stop(); }
  }

  void stop() {
    tm?.cancel(); ct?.close(); WakelockPlus.disable();
    if (mounted) setState(() => running = false);
  }

  Future<void> scan() async {
    if (busy || ct == null) return;
    busy = true;
    try {
      final open = (await ct!.positions()).map((p) => ((p['tradeData'] as Map)['symbolId'] as num).toInt()).toList();
      for (final e in ids.entries) {
        var b = await ct!.bars(e.value);
        if (b.length < 211) continue;
        b = b.sublist(0, b.length - 1); // descarta vela em formacao
        if (seen[e.key] == b.last.t) continue;
        seen[e.key] = b.last.t;
        final v = vote(b);
        log('${e.key}: compra ${v.buys} | venda ${v.sells}');
        final need = int.tryParse(votes.text) ?? 3;
        final dir = v.buys >= need && v.buys > v.sells ? 1 : (v.sells >= need && v.sells > v.buys ? -1 : 0);
        if (dir == 0 || open.contains(e.value) || open.length >= 5) continue;
        final d = det[e.value] ??= await ct!.detail(e.value);
        final lot = (d['lotSize'] as num).toInt(), step = (d['stepVolume'] as num).toInt(), mn = (d['minVolume'] as num).toInt();
        var vol = ((double.parse(lots.text) * lot) / step).floor() * step;
        if (vol < mn) vol = mn;
        await ct!.market(e.value, dir > 0, vol, v.atr * 1.5, v.atr * 3);
        open.add(e.value);
        log('ORDEM ${dir > 0 ? 'COMPRA' : 'VENDA'} ${e.key}');
      }
    } catch (e) { log('Erro: $e'); }
    busy = false;
  }

  Widget f(String l, TextEditingController c, {bool obscure = false}) => Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(controller: c, obscureText: obscure, enabled: !running,
          decoration: InputDecoration(labelText: l, border: const OutlineInputBorder(), isDense: true)));

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: const Text('TradeNexusPro')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        f('Client ID (openapi.ctrader.com)', cid), f('Client Secret', sec, obscure: true),
        f('Access Token', tok, obscure: true), f('Simbolos (nomes exatos da IC Markets)', syms),
        Row(children: [Expanded(child: f('Lotes', lots)), const SizedBox(width: 8), Expanded(child: f('Min. estrategias', votes))]),
        SwitchListTile(title: Text(live ? 'Conta REAL' : 'Conta DEMO'), value: live,
            onChanged: running ? null : (v) => setState(() => live = v)),
        FilledButton(onPressed: running ? stop : start, child: Text(running ? 'Parar' : 'Iniciar robo')),
        const Divider(height: 24),
        ...logs.take(60).map((l) => Text(l, style: const TextStyle(fontSize: 13))),
      ]));
}
